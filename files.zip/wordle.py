#!/usr/bin/env python3
"""
wordle-cli — a terminal Wordle clone.

Usage:
    python wordle.py            # random word
    python wordle.py --daily    # word chosen deterministically from today's date
    python wordle.py --stats    # just show stats and exit
"""

import argparse
import datetime
import random
import sys

from words import ANSWERS, VALID_GUESSES
import stats as stats_mod

WORD_LENGTH = 5
MAX_GUESSES = 6

# ANSI colors
GREEN = "\033[42m\033[30m"   # correct spot
YELLOW = "\033[43m\033[30m"  # wrong spot
GREY = "\033[100m\033[97m"   # not in word
RESET = "\033[0m"
BOLD = "\033[1m"
DIM = "\033[2m"

# Emoji equivalents for the shareable result grid
EMOJI_GREEN = "🟩"
EMOJI_YELLOW = "🟨"
EMOJI_GREY = "⬛"


def pick_word(daily: bool) -> str:
    if daily:
        today = datetime.date.today().isoformat()
        rng = random.Random(today)  # seeded -> same word all day, for everyone
        return rng.choice(ANSWERS)
    return random.choice(ANSWERS)


def score_guess(guess: str, answer: str):
    """
    Returns a list of MAX 5 statuses: 'green', 'yellow', or 'grey',
    correctly handling duplicate letters the way real Wordle does.
    """
    result = ["grey"] * WORD_LENGTH
    answer_chars = list(answer)

    # First pass: greens
    for i in range(WORD_LENGTH):
        if guess[i] == answer[i]:
            result[i] = "green"
            answer_chars[i] = None  # consume this letter

    # Second pass: yellows (only from letters not already consumed)
    for i in range(WORD_LENGTH):
        if result[i] == "green":
            continue
        if guess[i] in answer_chars:
            result[i] = "yellow"
            answer_chars[answer_chars.index(guess[i])] = None  # consume

    return result


def render_row(guess: str, statuses) -> str:
    colors = {"green": GREEN, "yellow": YELLOW, "grey": GREY}
    cells = []
    for ch, status in zip(guess, statuses):
        color = colors[status]
        cells.append(f"{color} {ch.upper()} {RESET}")
    return " ".join(cells)


def render_keyboard(letter_status: dict) -> str:
    rows = ["qwertyuiop", "asdfghjkl", "zxcvbnm"]
    colors = {"green": GREEN, "yellow": YELLOW, "grey": GREY, None: DIM}
    lines = []
    for row in rows:
        cells = []
        for ch in row:
            status = letter_status.get(ch)
            color = colors[status]
            cells.append(f"{color}{ch.upper()}{RESET}")
        lines.append(" ".join(cells))
    return "\n".join(lines)


def update_letter_status(letter_status: dict, guess: str, statuses):
    rank = {"grey": 0, "yellow": 1, "green": 2}
    for ch, status in zip(guess, statuses):
        current = letter_status.get(ch)
        if current is None or rank[status] > rank[current]:
            letter_status[ch] = status


def to_emoji_grid(history) -> str:
    emoji = {"green": EMOJI_GREEN, "yellow": EMOJI_YELLOW, "grey": EMOJI_GREY}
    lines = []
    for _, statuses in history:
        lines.append("".join(emoji[s] for s in statuses))
    return "\n".join(lines)


def prompt_guess() -> str:
    while True:
        guess = input(f"{BOLD}Guess: {RESET}").strip().lower()
        if len(guess) != WORD_LENGTH:
            print(f"  Must be {WORD_LENGTH} letters.")
            continue
        if not guess.isalpha():
            print("  Letters only.")
            continue
        if guess not in VALID_GUESSES:
            print("  Not in word list.")
            continue
        return guess


def play_game(daily: bool) -> None:
    answer = pick_word(daily)
    history = []
    letter_status = {}

    print(f"{BOLD}WORDLE (terminal edition){RESET}")
    print(f"Guess the {WORD_LENGTH}-letter word. You have {MAX_GUESSES} tries.\n")

    won = False
    for attempt in range(1, MAX_GUESSES + 1):
        guess = prompt_guess()
        statuses = score_guess(guess, answer)
        history.append((guess, statuses))
        update_letter_status(letter_status, guess, statuses)

        print()
        for g, s in history:
            print(render_row(g, s))
        print()
        print(render_keyboard(letter_status))
        print()

        if guess == answer:
            won = True
            break
        elif attempt < MAX_GUESSES:
            print(f"{DIM}Attempt {attempt}/{MAX_GUESSES} used.{RESET}\n")

    if won:
        print(f"{GREEN} Nice! {RESET} Solved in {len(history)}/{MAX_GUESSES}.\n")
    else:
        print(f"{GREY} Out of guesses. {RESET} The word was: {BOLD}{answer.upper()}{RESET}\n")

    print("Share:")
    print(to_emoji_grid(history))
    print()

    s = stats_mod.load_stats()
    stats_mod.record_result(s, won, len(history))
    print(stats_mod.format_stats(s))


def main():
    parser = argparse.ArgumentParser(description="Terminal Wordle clone")
    parser.add_argument("--daily", action="store_true", help="Play today's word (same for everyone)")
    parser.add_argument("--stats", action="store_true", help="Show stats and exit")
    args = parser.parse_args()

    if args.stats:
        s = stats_mod.load_stats()
        print(stats_mod.format_stats(s))
        sys.exit(0)

    try:
        play_game(daily=args.daily)
    except (KeyboardInterrupt, EOFError):
        print("\nBye!")
        sys.exit(0)


if __name__ == "__main__":
    main()
