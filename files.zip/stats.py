"""
Persistent stats for wordle-cli. Stored as JSON next to this file.
"""

import json
import os

STATS_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "stats.json")

DEFAULT_STATS = {
    "played": 0,
    "wins": 0,
    "current_streak": 0,
    "max_streak": 0,
    # index i = number of games won in (i+1) guesses
    "guess_distribution": [0, 0, 0, 0, 0, 0],
}


def load_stats():
    if not os.path.exists(STATS_PATH):
        return dict(DEFAULT_STATS)
    try:
        with open(STATS_PATH, "r") as f:
            data = json.load(f)
        # backfill any missing keys (e.g. if we add fields later)
        for key, val in DEFAULT_STATS.items():
            data.setdefault(key, val)
        return data
    except (json.JSONDecodeError, OSError):
        return dict(DEFAULT_STATS)


def save_stats(stats):
    with open(STATS_PATH, "w") as f:
        json.dump(stats, f, indent=2)


def record_result(stats, won: bool, guesses_used: int):
    stats["played"] += 1
    if won:
        stats["wins"] += 1
        stats["current_streak"] += 1
        stats["max_streak"] = max(stats["max_streak"], stats["current_streak"])
        if 1 <= guesses_used <= 6:
            stats["guess_distribution"][guesses_used - 1] += 1
    else:
        stats["current_streak"] = 0
    save_stats(stats)
    return stats


def format_stats(stats) -> str:
    played = stats["played"]
    wins = stats["wins"]
    win_pct = (wins / played * 100) if played else 0.0

    lines = []
    lines.append("Statistics")
    lines.append(f"  Played:        {played}")
    lines.append(f"  Win %:         {win_pct:.0f}")
    lines.append(f"  Current Streak:{stats['current_streak']:>4}")
    lines.append(f"  Max Streak:    {stats['max_streak']:>4}")
    lines.append("")
    lines.append("Guess Distribution")

    dist = stats["guess_distribution"]
    max_count = max(dist) if any(dist) else 1
    for i, count in enumerate(dist, start=1):
        bar_len = int((count / max_count) * 20) if max_count else 0
        bar = "█" * bar_len if count else ""
        lines.append(f"  {i}: {bar} {count}")

    return "\n".join(lines)
