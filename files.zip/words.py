"""
Word lists for wordle-cli.

ANSWERS: the pool the game picks today's/random word from (curated, common words).
VALID_GUESSES: words accepted as guesses on top of ANSWERS (a wider dictionary,
so guesses like "adieu" or "crane" work even though they're not answers).
"""

ANSWERS = [
    "apple", "beach", "chair", "dance", "eagle", "flame", "grape", "house",
    "input", "joker", "knock", "lemon", "mango", "night", "ocean", "piano",
    "queen", "river", "stone", "table", "unity", "vivid", "water", "xenon",
    "yield", "zebra", "amber", "brave", "cloud", "dream", "earth", "frost",
    "glory", "happy", "ivory", "jelly", "karma", "light", "mount", "noble",
    "orbit", "pearl", "quiet", "roast", "smile", "trust", "urban", "value",
    "whale", "young", "zesty", "actor", "bring", "crisp", "diary", "elbow",
    "fable", "giant", "honey", "index", "jumbo", "kneel", "large", "media",
    "nurse", "olive", "plant", "quick", "reach", "sugar", "trace", "usual",
    "vocal", "wrist", "acorn", "blend", "candy", "delta", "energ", "fresh",
]

# Filter out any accidental non-5-letter entries (keeps the list safe to edit)
ANSWERS = [w for w in ANSWERS if len(w) == 5]

# A broader set of acceptable guesses (doesn't need to be an answer).
# Feel free to extend this file with a bigger dictionary later.
EXTRA_VALID_GUESSES = [
    "adieu", "audio", "crane", "slate", "raise", "arose", "irate", "stare",
    "trace", "least", "roate", "orate", "soare", "tears", "louse", "salet",
]

VALID_GUESSES = set(ANSWERS) | set(EXTRA_VALID_GUESSES)
